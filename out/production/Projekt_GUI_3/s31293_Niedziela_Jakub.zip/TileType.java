public enum TileType {
    CROSS, CIRCLE, BLANK
}
